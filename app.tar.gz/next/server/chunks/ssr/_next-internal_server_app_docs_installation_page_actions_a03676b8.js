module.exports=[25438,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_docs_installation_page_actions_a03676b8.js.map