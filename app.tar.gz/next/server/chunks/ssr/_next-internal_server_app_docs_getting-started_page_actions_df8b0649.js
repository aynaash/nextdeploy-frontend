module.exports=[89163,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_docs_getting-started_page_actions_df8b0649.js.map