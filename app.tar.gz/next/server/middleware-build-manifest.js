globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/8a78cbfae800a97c.js",
    "static/chunks/8a80c7f2aa2a8276.js",
    "static/chunks/041b3e0e3c954a8f.js",
    "static/chunks/92e0473f5be0bb7a.js",
    "static/chunks/7af99b4fe779898e.js",
    "static/chunks/turbopack-4798b47f97ab07f6.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];