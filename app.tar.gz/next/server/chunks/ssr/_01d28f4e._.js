module.exports=[70864,a=>{a.n(a.i(33290))},23659,a=>{a.n(a.i(26859))},98441,a=>{a.n(a.i(15757))},51557,a=>{a.n(a.i(69338))},53554,a=>{a.n(a.i(96382))},71688,a=>{a.n(a.i(20178))},107,a=>{"use strict";var b=a.i(55008);function c(){return(0,b.jsxs)("div",{className:"prose prose-invert max-w-none",children:[(0,b.jsx)("h1",{className:"text-4xl font-bold text-white mb-6",children:"Secret Management with Doppler"}),(0,b.jsxs)("p",{className:"text-gray-300 text-lg mb-8",children:["NextDeploy is ",(0,b.jsx)("strong",{children:"Doppler-first"})," for managing secrets. No ",(0,b.jsx)("code",{className:"bg-slate-900 px-2 py-1 rounded text-emerald-400",children:".env"})," files, no git commits with secrets, just secure, encrypted secret management."]}),(0,b.jsx)("h2",{className:"text-2xl font-bold text-white mt-12 mb-4",children:"Why Doppler?"}),(0,b.jsxs)("ul",{className:"space-y-2 mb-8 text-gray-300",children:[(0,b.jsxs)("li",{className:"flex gap-3",children:[(0,b.jsx)("span",{className:"text-emerald-400",children:"🔐"}),(0,b.jsxs)("span",{children:[(0,b.jsx)("strong",{children:"Encrypted"})," - Secrets encrypted at rest and in transit"]})]}),(0,b.jsxs)("li",{className:"flex gap-3",children:[(0,b.jsx)("span",{className:"text-emerald-400",children:"🌍"}),(0,b.jsxs)("span",{children:[(0,b.jsx)("strong",{children:"Environment-scoped"})," - dev, staging, prod configs"]})]}),(0,b.jsxs)("li",{className:"flex gap-3",children:[(0,b.jsx)("span",{className:"text-emerald-400",children:"👥"}),(0,b.jsxs)("span",{children:[(0,b.jsx)("strong",{children:"Team-friendly"})," - Share secrets securely"]})]}),(0,b.jsxs)("li",{className:"flex gap-3",children:[(0,b.jsx)("span",{className:"text-emerald-400",children:"🔄"}),(0,b.jsxs)("span",{children:[(0,b.jsx)("strong",{children:"Auto-sync"})," - Update secrets without redeploying"]})]}),(0,b.jsxs)("li",{className:"flex gap-3",children:[(0,b.jsx)("span",{className:"text-emerald-400",children:"📊"}),(0,b.jsxs)("span",{children:[(0,b.jsx)("strong",{children:"Audit logs"})," - Track who changed what"]})]})]}),(0,b.jsx)("h2",{className:"text-2xl font-bold text-white mt-12 mb-4",children:"Setup"}),(0,b.jsx)("h3",{className:"text-xl font-semibold text-white mt-8 mb-3",children:"1. Create Doppler Account"}),(0,b.jsxs)("p",{className:"text-gray-300 mb-6",children:["Sign up at ",(0,b.jsx)("a",{href:"https://doppler.com",className:"text-emerald-400 hover:text-emerald-300",children:"doppler.com"})," (free tier available)."]}),(0,b.jsx)("h3",{className:"text-xl font-semibold text-white mt-8 mb-3",children:"2. Install Doppler CLI"}),(0,b.jsx)("pre",{className:"bg-slate-900 border border-slate-700 rounded-lg p-4 mb-8 overflow-x-auto text-sm",children:(0,b.jsx)("code",{className:"text-emerald-400",children:`# macOS
brew install dopplerhq/cli/doppler

# Linux
curl -Ls https://cli.doppler.com/install.sh | sh

# Windows
scoop install doppler`})}),(0,b.jsx)("h3",{className:"text-xl font-semibold text-white mt-8 mb-3",children:"3. Login"}),(0,b.jsx)("pre",{className:"bg-slate-900 border border-slate-700 rounded-lg p-4 mb-8 overflow-x-auto",children:(0,b.jsx)("code",{className:"text-emerald-400",children:"doppler login"})}),(0,b.jsx)("h3",{className:"text-xl font-semibold text-white mt-8 mb-3",children:"4. Create Project"}),(0,b.jsx)("pre",{className:"bg-slate-900 border border-slate-700 rounded-lg p-4 mb-8 overflow-x-auto",children:(0,b.jsx)("code",{className:"text-emerald-400",children:"doppler projects create my-app"})}),(0,b.jsx)("h3",{className:"text-xl font-semibold text-white mt-8 mb-3",children:"5. Set Up Environments"}),(0,b.jsx)("pre",{className:"bg-slate-900 border border-slate-700 rounded-lg p-4 mb-8 overflow-x-auto text-sm",children:(0,b.jsx)("code",{className:"text-emerald-400",children:`# Development
doppler setup --project my-app --config dev

# Staging
doppler setup --project my-app --config stg

# Production
doppler setup --project my-app --config prd`})}),(0,b.jsx)("h2",{className:"text-2xl font-bold text-white mt-12 mb-4",children:"Adding Secrets"}),(0,b.jsx)("h3",{className:"text-xl font-semibold text-white mt-8 mb-3",children:"Via CLI"}),(0,b.jsx)("pre",{className:"bg-slate-900 border border-slate-700 rounded-lg p-4 mb-8 overflow-x-auto text-sm",children:(0,b.jsx)("code",{className:"text-emerald-400",children:`# Switch to production config
doppler setup --project my-app --config prd

# Add secrets
doppler secrets set DATABASE_URL="postgresql://..."
doppler secrets set API_KEY="sk_live_..."
doppler secrets set STRIPE_SECRET="sk_..."`})}),(0,b.jsx)("h3",{className:"text-xl font-semibold text-white mt-8 mb-3",children:"Via Dashboard"}),(0,b.jsxs)("ol",{className:"space-y-2 mb-8 text-gray-300 list-decimal list-inside",children:[(0,b.jsxs)("li",{children:["Go to ",(0,b.jsx)("a",{href:"https://dashboard.doppler.com",className:"text-emerald-400 hover:text-emerald-300",children:"dashboard.doppler.com"})]}),(0,b.jsx)("li",{children:"Select your project"}),(0,b.jsx)("li",{children:"Select environment (dev/stg/prd)"}),(0,b.jsx)("li",{children:'Click "Add Secret"'}),(0,b.jsx)("li",{children:"Enter name and value"})]}),(0,b.jsx)("h2",{className:"text-2xl font-bold text-white mt-12 mb-4",children:"Using Secrets Locally"}),(0,b.jsx)("h3",{className:"text-xl font-semibold text-white mt-8 mb-3",children:"Development"}),(0,b.jsx)("pre",{className:"bg-slate-900 border border-slate-700 rounded-lg p-4 mb-8 overflow-x-auto text-sm",children:(0,b.jsx)("code",{className:"text-emerald-400",children:`# Run Next.js with Doppler
doppler run -- npm run dev

# Or export to shell
eval $(doppler secrets download --no-file --format env-no-quotes)
npm run dev`})}),(0,b.jsx)("h3",{className:"text-xl font-semibold text-white mt-8 mb-3",children:"Build with Secrets"}),(0,b.jsx)("pre",{className:"bg-slate-900 border border-slate-700 rounded-lg p-4 mb-8 overflow-x-auto",children:(0,b.jsx)("code",{className:"text-emerald-400",children:"doppler run -- nextdeploy build"})}),(0,b.jsx)("h2",{className:"text-2xl font-bold text-white mt-12 mb-4",children:"Using Secrets in Production"}),(0,b.jsx)("h3",{className:"text-xl font-semibold text-white mt-8 mb-3",children:"Method 1: Doppler Service Token (Recommended)"}),(0,b.jsxs)("ol",{className:"space-y-4 mb-8 text-gray-300 list-decimal list-inside",children:[(0,b.jsxs)("li",{children:[(0,b.jsx)("strong",{className:"text-white",children:"Generate service token:"}),(0,b.jsx)("pre",{className:"bg-slate-900 border border-slate-700 rounded-lg p-3 mt-2 overflow-x-auto",children:(0,b.jsx)("code",{className:"text-emerald-400",children:"doppler configs tokens create production --project my-app"})})]}),(0,b.jsxs)("li",{children:[(0,b.jsx)("strong",{className:"text-white",children:"Add to server:"}),(0,b.jsx)("pre",{className:"bg-slate-900 border border-slate-700 rounded-lg p-3 mt-2 overflow-x-auto",children:(0,b.jsx)("code",{className:"text-emerald-400",children:'ssh deploy@your-server echo "DOPPLER_TOKEN=dp.st.xxx" | sudo tee -a /etc/environment'})})]}),(0,b.jsxs)("li",{children:[(0,b.jsx)("strong",{className:"text-white",children:"Update nextdeploy.yml:"}),(0,b.jsx)("pre",{className:"bg-slate-900 border border-slate-700 rounded-lg p-3 mt-2 overflow-x-auto text-sm",children:(0,b.jsx)("code",{className:"text-emerald-400",children:`secrets:
  provider: doppler
  project: my-app
  config: prd`})})]}),(0,b.jsxs)("li",{children:[(0,b.jsx)("strong",{className:"text-white",children:"Deploy:"}),(0,b.jsx)("pre",{className:"bg-slate-900 border border-slate-700 rounded-lg p-3 mt-2 overflow-x-auto",children:(0,b.jsx)("code",{className:"text-emerald-400",children:"nextdeploy ship"})})]})]}),(0,b.jsx)("h2",{className:"text-2xl font-bold text-white mt-12 mb-4",children:"Common Secrets"}),(0,b.jsx)("h3",{className:"text-xl font-semibold text-white mt-8 mb-3",children:"Database"}),(0,b.jsx)("pre",{className:"bg-slate-900 border border-slate-700 rounded-lg p-4 mb-8 overflow-x-auto text-sm",children:(0,b.jsx)("code",{className:"text-emerald-400",children:`doppler secrets set DATABASE_URL="postgresql://user:pass@host:5432/db"
doppler secrets set REDIS_URL="redis://localhost:6379"`})}),(0,b.jsx)("h3",{className:"text-xl font-semibold text-white mt-8 mb-3",children:"Authentication"}),(0,b.jsx)("pre",{className:"bg-slate-900 border border-slate-700 rounded-lg p-4 mb-8 overflow-x-auto text-sm",children:(0,b.jsx)("code",{className:"text-emerald-400",children:`doppler secrets set NEXTAUTH_SECRET="your-secret-here"
doppler secrets set NEXTAUTH_URL="https://myapp.com"
doppler secrets set GITHUB_CLIENT_ID="..."
doppler secrets set GITHUB_CLIENT_SECRET="..."`})}),(0,b.jsx)("h3",{className:"text-xl font-semibold text-white mt-8 mb-3",children:"APIs"}),(0,b.jsx)("pre",{className:"bg-slate-900 border border-slate-700 rounded-lg p-4 mb-8 overflow-x-auto text-sm",children:(0,b.jsx)("code",{className:"text-emerald-400",children:`doppler secrets set STRIPE_SECRET_KEY="sk_live_..."
doppler secrets set SENDGRID_API_KEY="SG...."
doppler secrets set AWS_ACCESS_KEY_ID="..."
doppler secrets set AWS_SECRET_ACCESS_KEY="..."`})}),(0,b.jsx)("h2",{className:"text-2xl font-bold text-white mt-12 mb-4",children:"Best Practices"}),(0,b.jsx)("h3",{className:"text-xl font-semibold text-white mt-8 mb-3",children:"1. Never Commit Secrets"}),(0,b.jsx)("pre",{className:"bg-slate-900 border border-slate-700 rounded-lg p-4 mb-8 overflow-x-auto text-sm",children:(0,b.jsx)("code",{className:"text-emerald-400",children:`# .gitignore
.env
.env.*
!.env.example
master.key
*.encrypted`})}),(0,b.jsx)("h3",{className:"text-xl font-semibold text-white mt-8 mb-3",children:"2. Use .env.example"}),(0,b.jsx)("pre",{className:"bg-slate-900 border border-slate-700 rounded-lg p-4 mb-8 overflow-x-auto text-sm",children:(0,b.jsx)("code",{className:"text-emerald-400",children:`# .env.example
DATABASE_URL=postgresql://localhost/myapp_dev
API_KEY=your_api_key_here
STRIPE_SECRET=sk_test_...`})}),(0,b.jsx)("h3",{className:"text-xl font-semibold text-white mt-8 mb-3",children:"3. Rotate Secrets Regularly"}),(0,b.jsx)("pre",{className:"bg-slate-900 border border-slate-700 rounded-lg p-4 mb-8 overflow-x-auto",children:(0,b.jsx)("code",{className:"text-emerald-400",children:`# Generate new secret
doppler secrets set API_KEY="new_key_here"

# Restart app to pick up changes
nextdeploy restart`})}),(0,b.jsx)("h2",{className:"text-2xl font-bold text-white mt-12 mb-4",children:"Troubleshooting"}),(0,b.jsx)("h3",{className:"text-xl font-semibold text-white mt-8 mb-3",children:"Secrets not loading"}),(0,b.jsx)("pre",{className:"bg-slate-900 border border-slate-700 rounded-lg p-4 mb-8 overflow-x-auto text-sm",children:(0,b.jsx)("code",{className:"text-emerald-400",children:`# Check current config
doppler configure get

# Download secrets to verify
doppler secrets download --no-file`})}),(0,b.jsx)("h3",{className:"text-xl font-semibold text-white mt-8 mb-3",children:"Invalid token"}),(0,b.jsx)("pre",{className:"bg-slate-900 border border-slate-700 rounded-lg p-4 mb-8 overflow-x-auto text-sm",children:(0,b.jsx)("code",{className:"text-emerald-400",children:`# Re-login
doppler login

# Verify setup
doppler setup`})})]})}a.s(["default",()=>c])}];

//# sourceMappingURL=_01d28f4e._.js.map