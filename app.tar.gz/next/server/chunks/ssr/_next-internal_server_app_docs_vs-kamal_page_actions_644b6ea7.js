module.exports=[45734,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_docs_vs-kamal_page_actions_644b6ea7.js.map