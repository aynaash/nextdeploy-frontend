module.exports=[62387,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_docs_configuration_page_actions_31cdee15.js.map