module.exports=[70864,a=>{a.n(a.i(33290))},23659,a=>{a.n(a.i(26859))},98441,a=>{a.n(a.i(15757))},51557,a=>{a.n(a.i(69338))},53554,a=>{a.n(a.i(96382))},71688,a=>{a.n(a.i(20178))},73356,a=>{"use strict";var b=a.i(55008);function c(){return(0,b.jsxs)("div",{className:"prose prose-invert max-w-none",children:[(0,b.jsx)("h1",{className:"text-4xl font-bold text-white mb-6",children:"Troubleshooting Guide"}),(0,b.jsx)("p",{className:"text-gray-300 text-lg mb-8",children:"Common issues and solutions when using NextDeploy's Native Execution engine."}),(0,b.jsx)("h2",{className:"text-2xl font-bold text-white mt-12 mb-4",children:"Connection Issues"}),(0,b.jsx)("h3",{className:"text-xl font-semibold text-white mt-8 mb-3",children:"SSH connection failed"}),(0,b.jsx)("p",{className:"text-emerald-400 font-semibold mb-3",children:"Error:"}),(0,b.jsx)("pre",{className:"bg-slate-900 border border-slate-700 rounded-lg p-4 mb-6 overflow-x-auto text-sm",children:(0,b.jsx)("code",{className:"text-emerald-400",children:"Error: SSH connection failed: Permission denied (publickey)"})}),(0,b.jsx)("p",{className:"text-emerald-400 font-semibold mb-3",children:"Solution:"}),(0,b.jsx)("pre",{className:"bg-slate-900 border border-slate-700 rounded-lg p-4 mb-8 overflow-x-auto text-sm",children:(0,b.jsx)("code",{className:"text-emerald-400",children:`# Test SSH connection directly
ssh -i ~/.ssh/id_rsa deploy@YOUR_SERVER_IP

# Generate new SSH key if needed
ssh-keygen -t ed25519 -C "your_email@example.com"

# Copy key to server
ssh-copy-id -i ~/.ssh/id_rsa deploy@YOUR_SERVER_IP

# Update nextdeploy.yml with correct key path`})}),(0,b.jsx)("h2",{className:"text-2xl font-bold text-white mt-12 mb-4",children:"Runtime & Deployment Issues"}),(0,b.jsx)("h3",{className:"text-xl font-semibold text-white mt-8 mb-3",children:"NextDeploy Daemon Not Responding"}),(0,b.jsx)("p",{className:"text-emerald-400 font-semibold mb-3",children:"Error:"}),(0,b.jsx)("pre",{className:"bg-slate-900 border border-slate-700 rounded-lg p-4 mb-6 overflow-x-auto text-sm",children:(0,b.jsx)("code",{className:"text-emerald-400",children:"Connection refused to NextDeploy Daemon on port 8443"})}),(0,b.jsx)("p",{className:"text-emerald-400 font-semibold mb-3",children:"Solution:"}),(0,b.jsx)("pre",{className:"bg-slate-900 border border-slate-700 rounded-lg p-4 mb-8 overflow-x-auto text-sm",children:(0,b.jsx)("code",{className:"text-emerald-400",children:`# 1. SSH into your VPS
ssh deploy@YOUR_SERVER_IP

# 2. Check the daemon status
sudo systemctl status nextdeployd

# 3. Restart the daemon if necessary
sudo systemctl restart nextdeployd

# 4. Alternatively, replay the prepare step locally
nextdeploy prepare`})}),(0,b.jsx)("h3",{className:"text-xl font-semibold text-white mt-8 mb-3",children:"Application crashes on startup"}),(0,b.jsx)("p",{className:"text-gray-300 mb-4",children:(0,b.jsx)("strong",{className:"text-white",children:"Symptoms:"})}),(0,b.jsxs)("ul",{className:"space-y-2 mb-8 text-gray-300 list-disc list-inside",children:[(0,b.jsx)("li",{children:"Systemd service enters a failed state"}),(0,b.jsx)("li",{children:"Health checks fail during deployment"}),(0,b.jsx)("li",{children:"502 Bad Gateway from Caddy"})]}),(0,b.jsx)("p",{className:"text-emerald-400 font-semibold mb-3",children:"Debug steps:"}),(0,b.jsx)("pre",{className:"bg-slate-900 border border-slate-700 rounded-lg p-4 mb-8 overflow-x-auto text-sm",children:(0,b.jsx)("code",{className:"text-emerald-400",children:`# 1. Check systemd native logs via NextDeploy CLI
nextdeploy logs --tail 100

# 2. Re-run locally to ensure build succeeds
bun run build && bun run start

# 3. SSH in to check raw application logs
ssh deploy@SERVER journalctl -u nextdeploy-myapp.service -n 50 --no-pager

# 4. Check for missing runtime environment variables
doppler run -- nextdeploy deploy`})}),(0,b.jsx)("h3",{className:"text-xl font-semibold text-white mt-8 mb-3",children:"Port already in use"}),(0,b.jsx)("p",{className:"text-emerald-400 font-semibold mb-3",children:"Error:"}),(0,b.jsx)("pre",{className:"bg-slate-900 border border-slate-700 rounded-lg p-4 mb-6 overflow-x-auto text-sm",children:(0,b.jsx)("code",{className:"text-emerald-400",children:"Error: listen EADDRINUSE: address already in use :::3000"})}),(0,b.jsx)("p",{className:"text-emerald-400 font-semibold mb-3",children:"Solution:"}),(0,b.jsx)("pre",{className:"bg-slate-900 border border-slate-700 rounded-lg p-4 mb-8 overflow-x-auto text-sm",children:(0,b.jsx)("code",{className:"text-emerald-400",children:`# NextDeploy usually handles port swapping, but if a rogue process exists:

# 1. SSH into the server
ssh deploy@SERVER

# 2. Find the rogue process
sudo lsof -i :3000

# 3. Kill the process
sudo kill -9 PID`})}),(0,b.jsx)("h2",{className:"text-2xl font-bold text-white mt-12 mb-4",children:"Secret Management Issues (Doppler)"}),(0,b.jsx)("h3",{className:"text-xl font-semibold text-white mt-8 mb-3",children:"Doppler token invalid"}),(0,b.jsx)("p",{className:"text-emerald-400 font-semibold mb-3",children:"Error:"}),(0,b.jsx)("pre",{className:"bg-slate-900 border border-slate-700 rounded-lg p-4 mb-6 overflow-x-auto text-sm",children:(0,b.jsx)("code",{className:"text-emerald-400",children:"Error: invalid Doppler token"})}),(0,b.jsx)("p",{className:"text-emerald-400 font-semibold mb-3",children:"Solution:"}),(0,b.jsx)("pre",{className:"bg-slate-900 border border-slate-700 rounded-lg p-4 mb-8 overflow-x-auto text-sm",children:(0,b.jsx)("code",{className:"text-emerald-400",children:`# Re-login to Doppler
doppler login

# Verify setup
doppler setup

# Check token
doppler configure get token`})}),(0,b.jsx)("h3",{className:"text-xl font-semibold text-white mt-8 mb-3",children:"Secrets not loading"}),(0,b.jsx)("p",{className:"text-emerald-400 font-semibold mb-3",children:"Error:"}),(0,b.jsx)("pre",{className:"bg-slate-900 border border-slate-700 rounded-lg p-4 mb-6 overflow-x-auto text-sm",children:(0,b.jsx)("code",{className:"text-emerald-400",children:"Error: DATABASE_URL is not defined"})}),(0,b.jsx)("p",{className:"text-emerald-400 font-semibold mb-3",children:"Solution:"}),(0,b.jsx)("pre",{className:"bg-slate-900 border border-slate-700 rounded-lg p-4 mb-8 overflow-x-auto text-sm",children:(0,b.jsx)("code",{className:"text-emerald-400",children:`# Verify secrets exist in Doppler
doppler secrets

# Force NextDeploy to re-sync environmental variables
nextdeploy deploy --sync-secrets`})}),(0,b.jsx)("h2",{className:"text-2xl font-bold text-white mt-12 mb-4",children:"Need Help?"}),(0,b.jsxs)("ul",{className:"space-y-3 text-gray-300 mb-8",children:[(0,b.jsxs)("li",{className:"flex gap-3",children:[(0,b.jsx)("span",{className:"text-emerald-400",children:"•"}),(0,b.jsxs)("span",{children:[(0,b.jsx)("a",{href:"https://github.com/aynaash/nextdeploy/issues",className:"text-emerald-400 hover:text-emerald-300",children:"Report bugs"})," - GitHub Issues"]})]}),(0,b.jsxs)("li",{className:"flex gap-3",children:[(0,b.jsx)("span",{className:"text-emerald-400",children:"•"}),(0,b.jsxs)("span",{children:[(0,b.jsx)("a",{href:"https://github.com/aynaash/nextdeploy/discussions",className:"text-emerald-400 hover:text-emerald-300",children:"Ask questions"})," - GitHub Discussions"]})]})]})]})}a.s(["default",()=>c])}];

//# sourceMappingURL=_3e72901b._.js.map