module.exports=[10561,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_docs_first-deployment_page_actions_ab74c88f.js.map