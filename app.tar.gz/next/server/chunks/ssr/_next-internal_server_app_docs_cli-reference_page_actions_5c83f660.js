module.exports=[79362,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_docs_cli-reference_page_actions_5c83f660.js.map